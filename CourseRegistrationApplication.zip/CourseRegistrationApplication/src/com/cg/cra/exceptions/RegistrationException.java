package com.cg.cra.exceptions;

public class RegistrationException extends Exception {

	public RegistrationException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RegistrationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
