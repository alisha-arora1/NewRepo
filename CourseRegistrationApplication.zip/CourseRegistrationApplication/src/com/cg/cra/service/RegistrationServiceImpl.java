package com.cg.cra.service;

import java.time.LocalDate;
import java.util.List;
import com.cg.cra.dao.RegistrationDao;
import com.cg.cra.dao.RegistrationDaoImpl;
import com.cg.cra.dto.Course;
import com.cg.cra.dto.Registration;
import com.cg.cra.exceptions.RegistrationException;

public class RegistrationServiceImpl implements RegistrationService {
RegistrationDao rdao = new RegistrationDaoImpl();
	@Override
	public List<Course> getAllCourses() throws RegistrationException {
		return rdao.getAllCourses();
	}
	@Override
	public long register(Registration registration) throws RegistrationException {
		return rdao.registerCourse(registration);
	}
	@Override
	public boolean validateCourseId(long courseId) throws RegistrationException {
		return rdao.validateCourseId(courseId);
	}
	@Override
	public boolean validateRegistrationDetails(Registration reg) throws RegistrationException {
		if(!reg.getStudentName().matches("[A-Z][a-z]{3,}")) {
			throw new RegistrationException("Student name should start with capital letter, min 4 letters");
		}
		if(!reg.getPhoneNo().matches("[0-9]{10}")) {
			throw new RegistrationException("Phone number should contain 10 digits");
		}
		if(reg.getRegDate().isBefore(LocalDate.now())) {
			throw new RegistrationException("Registration date should be today or "
					+ "later");
		}
		return true;
	}
}
