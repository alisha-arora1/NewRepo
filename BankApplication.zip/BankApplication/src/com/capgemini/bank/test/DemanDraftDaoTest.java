package com.capgemini.bank.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.bank.Exception.DemandDraftException;
import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;

public class DemanDraftDaoTest {

	static DemandDraftDAO dao;
	static DemandDraft draft;

	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		 dao = new DemandDraftDAO();
		 draft = new DemandDraft();
	}

	@Test
	public void testaddDemandDraftDetails() throws DemandDraftException {

		assertNotNull(dao.addDemandDraftDetails(draft));

	}

	/***************************************
	 * Test case for addDemandDraftDetails()
	 * 
	 **************************************/

	@Ignore
	@Test
	public void testaddDemandDraftDetails1() throws DemandDraftException {
		// increment the number next time you test for positive test case
		assertEquals(10001, dao.addDemandDraftDetails(draft));
	}

	/************************************
	 * Test case for addDemandDraftDetails()
	 * 
	 ************************************/

	@Test
	public void testaddDemandDraftDetails2() throws DemandDraftException {

		draft.setCustomer_name("John");
		draft.setIn_favor_of("Cpgemini");
		draft.setPhone_number("9768587350");
		draft.setDd_amount(45000);
		assertTrue("Data Inserted successfully",
				Integer.parseInt(dao.addDemandDraftDetails(draft)) > 1000);

	}
	/****************************************************
	 * Test case for getByTransactionId()
	 ******************************************************/
	
    @Test
	public void testByTransactionId() throws DemandDraftException{
		assertNotNull(dao.getDemandDraftDetails("10010"));
	}

	@Ignore
	@Test
	public void testByTransactionId1() throws DemandDraftException{
		assertEquals("TestName", dao.getDemandDraftDetails("10010").getCustomer_name());
	}

}
