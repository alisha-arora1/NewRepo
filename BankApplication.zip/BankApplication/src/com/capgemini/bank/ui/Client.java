package com.capgemini.bank.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.bank.Exception.DemandDraftException;
import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;

public class Client {
	
	static Scanner sc = new Scanner(System.in);
	static DemandDraftService demandDraftService = null;
	static IDemandDraftService IdemandDraftService = null;
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) {
		PropertyConfigurator.configure("resources//log4j.properties");
		DemandDraft demandDraft = null;

		String transaction_id = null;
		int option = 0;
		
		while (true) {

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("   Capgemini Bank   ");
			System.out.println("_______________________________\n");

			System.out.println("1.Enter Demand Draft Details ");
			System.out.println("2.Print Demand Draft");
			System.out.println("3.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accept option

			try {
				option = sc.nextInt();

				switch (option) {
				
				case 1:
					
				    while (demandDraft == null) {
					demandDraft = populateDemandDraft();
					
				}

				try {
					demandDraftService = new DemandDraftService();
					transaction_id = demandDraftService.addDemandDraftDetails(demandDraft);

					System.out.println("Your Demand Draft request has been successfully" 
										+"registered along with the"+transaction_id);
					

				} catch (DemandDraftException demanddraftException) {
					logger.error("exception occured", demanddraftException);
					System.out.println("ERROR : "
							+ demanddraftException.getMessage());
				} finally {
					transaction_id = null;
					demandDraftService = null;
					demandDraft = null;
				}
				break;
				
			case 2:

				demandDraftService = new DemandDraftService();

				System.out.println("Enter numeric transaction id:");
				transaction_id = sc.next();

				while (true) {
					if (demandDraftService.validateDraftId(transaction_id)) {
						break;
					} else {
						System.err
								.println("Please enter numeric transaction id only, try again");
						transaction_id = sc.next();
					}
				}

				demandDraft = getDemandDraftDetails(transaction_id);

				if (demandDraft != null) {
					System.out.println("Customer_name             :"
							+ demandDraft.getCustomer_name());
					System.out.println("In_favor_of          :"
							+ demandDraft.getIn_favor_of());
					System.out.println("Phone Number     :"
							+ demandDraft.getPhone_number());
					System.out.println("Date_of_transaction       :"
							+ demandDraft.getDate_of_transaction());
					System.out.println("Amount       :"
							+ (demandDraft.getDd_amount()+demandDraft.getDd_commission()));
					System.out.println("Dd_description()  :"
							+ demandDraft.getDd_description());
				} else {
					System.err
							.println("There are no DD requests  associated with transaction id "
									+ transaction_id);
				}

				break;
	
	
			case 3:

				System.out.print("Exit Trust Application");
				System.exit(0);
				break;
			default:
				System.out.println("Enter a valid option[1-3]");
			}// end of switch
		}

		catch (InputMismatchException e) {
			sc.nextLine();
			System.err.println("Please enter a numeric value, try again");
		}

	}// end of while
}// end of try

/*
 * This function will call the service layer method and return the bean
 * object which is populated by the information of the given donorId in
 * parameter
 */
private static DemandDraft getDemandDraftDetails(String transaction_id) {
	DemandDraft demandDraft = null;
	IdemandDraftService = new DemandDraftService();

	try {
		demandDraft = IdemandDraftService.getDemandDraftDetails(transaction_id);
	} catch (DemandDraftException demanddraftException) {
		logger.error("exception occured ", demanddraftException);
		System.out.println("ERROR : " + demanddraftException.getMessage());
	}

	IdemandDraftService = null;
	return demandDraft;
}


/* * This function will be called by main and will return a validated bean
 * object OR null if details are invalid*/
 
private static DemandDraft populateDemandDraft() {

	// Reading and setting the values for the demandDraft
	
	DemandDraft demandDraft = new DemandDraft();;

	System.out.println("\n Enter Details");

	System.out.println("Enter the name of customer: ");
	demandDraft.setCustomer_name(sc.next());

	System.out.println("In favor of: ");
	demandDraft.setIn_favor_of(sc.next());

	System.out.println("Enter customer phone number: ");
	demandDraft.setPhone_number(sc.next());
	
	System.out.println("Enter Demand Draft amount(in Rs)");
	demandDraft.setDd_amount(sc.nextInt());
	
    System.out.println("Enter Remarks");
	demandDraft.setDd_description(sc.next());
	
	demandDraftService = new DemandDraftService();

	try {
		demandDraftService.validateDemandDraft(demandDraft);
		return demandDraft;
	} catch (DemandDraftException demanddraftException) {
		logger.error("exception occured", demanddraftException);
		System.err.println("Invalid data:");
		System.err.println(demanddraftException.getMessage() + " \n Try again..");
		System.exit(0);

	}
	return null;

}

				}



