package com.capgemini.bank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.bank.Exception.DemandDraftException;
import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.utils.DBConnection;

public class DemandDraftDAO implements IDemandDraftDAO {
	
	
	Logger logger=Logger.getRootLogger();
	public DemandDraftDAO()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}

	@SuppressWarnings("resource")
	public String addDemandDraftDetails(DemandDraft demandDraft) throws DemandDraftException{
		
        Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		String transaction_id=null;
		
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);
			preparedStatement.setString(1,demandDraft.getCustomer_name());			
			preparedStatement.setString(2,demandDraft.getIn_favor_of());
			preparedStatement.setString(3,demandDraft.getPhone_number());
			preparedStatement.setInt(4,demandDraft.getDd_amount());
			preparedStatement.setInt(5,demandDraft.getDd_commission());
			preparedStatement.setString(6,demandDraft.getDd_description());
			
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QueryMapper.TRANS_ID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				transaction_id=resultSet.getString(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new DemandDraftException("Inserting Demand Draft details failed ");

			}
			else
			{
				logger.info("Demand Draft details added successfully:");
				return transaction_id;
			}

		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new DemandDraftException("Tehnical problem occured refer log");
		}

		finally
		{
			try 
			{
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new DemandDraftException("Error in closing db connection");

			}
		}
		
		
	}

	@Override
	public DemandDraft getDemandDraftDetails(String transaction_id)throws DemandDraftException {
		
		Connection connection=DBConnection.getInstance().getConnection();
		
		
		PreparedStatement preparedStatement=null;
		ResultSet resultset = null;
		DemandDraft demandDraft=null;
		
		try
		{
			preparedStatement=connection.prepareStatement(QueryMapper.GET_DRAFT_DETAILS_QUERY);
			preparedStatement.setString(1,transaction_id);
			resultset=preparedStatement.executeQuery();
			
			if(resultset.next())
			{
				demandDraft = new DemandDraft();
				demandDraft.setCustomer_name(resultset.getString(1));
				demandDraft.setIn_favor_of(resultset.getString(2));
				demandDraft.setPhone_number(resultset.getString(3));
				demandDraft.setDate_of_transaction(resultset.getDate(4));
				demandDraft.setDd_amount(resultset.getInt(5));
				demandDraft.setDd_commission(resultset.getInt(6));
				demandDraft.setDd_description(resultset.getString(7));
				
			}
			
			if( demandDraft != null)
			{
				logger.info("Record Found Successfully");
				return demandDraft;
			}
			else
			{
				logger.info("Record Not Found Successfully");
				return null;
			}
			
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
			throw new DemandDraftException(e.getMessage());
		}
		finally
		{
			try 
			{
				resultset.close();
				preparedStatement.close();
				connection.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new DemandDraftException("Error in closing db connection");

			}
		}
		
	}
	

}
