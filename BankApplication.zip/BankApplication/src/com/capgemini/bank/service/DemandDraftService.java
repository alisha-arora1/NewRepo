package com.capgemini.bank.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.bank.Exception.DemandDraftException;
import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.dao.IDemandDraftDAO;

public class DemandDraftService implements IDemandDraftService {
	
	IDemandDraftDAO demandDraftDao;

	@Override
	public String addDemandDraftDetails(DemandDraft demandDraft) throws DemandDraftException{
		// Input validation Logic         
				try{
					if(!(Pattern.matches("[A-Z a-z]+",demandDraft.getCustomer_name()))){
						throw new DemandDraftException("Name contains invalid characters");
					}
					if(!(Pattern.matches("[0-9]{10}+",demandDraft.getPhone_number()))){
						throw new  DemandDraftException("Mobile Number has invalid characters/invalid length");
					}
					if(demandDraft.getDd_amount()<=0){
						throw new DemandDraftException("Invalid amount"); 
					}
				}catch(DemandDraftException e){
					System.err.println(e.getMessage());
					System.exit(0);
				}
				// End of Input validation Logic       
				
	
	// Commission calculation
	
			int dd_commission = 0;
			try{
				int amnt = demandDraft.getDd_amount();
				dd_commission = 0;
				if(amnt<=5000){
					dd_commission = 10;
				}else if(amnt>5000 && amnt<=10000){
					dd_commission = 41;
				}else if(amnt>10000 && amnt<=100000){
					dd_commission = 51;
				}else if(amnt>100000 && amnt<=500000){
					dd_commission = 306;
				}else{
					throw new DemandDraftException("DD Amount should be less than Rs.5,00,000");
				}
			}catch(DemandDraftException e){
				System.err.println(e.getMessage());
				
				System.exit(0);
			}
			// End of Commission calculation
			
			demandDraft.setDd_commission(dd_commission);
			
			// SERVICE LAYER TO DAO LAYER
			DemandDraftDAO dao = new DemandDraftDAO();
			String transaction_id = dao.addDemandDraftDetails(demandDraft);
			
			return transaction_id;
	}
   
    public DemandDraft getDemandDraftDetails (int transactionId){
		
		
		return null; 
		
	}
	public void validateDemandDraft(DemandDraft demandDraft)throws DemandDraftException {
		// TODO Auto-generated method stub
		return;
	}
	@Override
	public DemandDraft getDemandDraftDetails(String transaction_id) throws DemandDraftException{
		demandDraftDao=new DemandDraftDAO();
		DemandDraft demandDraft=null;
		demandDraft=demandDraftDao.getDemandDraftDetails(transaction_id);
		return demandDraft;
		
	}

	public boolean validateDraftId(String transaction_id) {
		Pattern idPattern = Pattern.compile("[0-9]{1,6}");
		Matcher idMatcher = idPattern.matcher(transaction_id);
		
		if(idMatcher.matches())
			return true;
		else
			return false;		
	}

}
