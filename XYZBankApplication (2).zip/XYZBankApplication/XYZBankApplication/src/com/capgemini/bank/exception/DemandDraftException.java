package com.capgemini.bank.exception;

public class DemandDraftException extends Exception 
{
	private static final long serialVersionUID = 726264577455921591L;

	public DemandDraftException(String message) 
	{
		
		super(message);
	}
}
