package com.capgemini.bank.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.BeforeClass;
import org.junit.Ignore;
import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.exception.DemandDraftException;




public class bankTest {
	
	 static DemandDraftDAO dao;
	    static DemandDraft demanddraft;
	    
	    
	    @BeforeClass
	    public static void initialize() {
	        dao = new DemandDraftDAO();
	        demanddraft = new DemandDraft();
	    }
	    
	    @Test
	    public void testAddDemandDraftDetails() throws DemandDraftException {

	        assertNotNull(dao.addDraftDetails(demanddraft));
	    }
	    
	    @Ignore
	    @Test
	    public void testAddDemandDraftDetails1() throws DemandDraftException {
	        assertEquals(10001, dao.addDraftDetails(demanddraft));
	    }
	    
	    @Test
	    public void testAddDemandDraftDetails2() throws DemandDraftException {
	    	
	    	
	    	demanddraft.setCustomer_name("ABC");
	    	demanddraft.setPhone_number("1234567890");
	    	demanddraft.setDd_amount(5500);
	    	demanddraft.setIn_favor_of("capgemini");
	    	demanddraft.setDd_description("capgemini");
	        assertTrue("Data Inserted successfully",
	                Integer.parseInt(dao.addDraftDetails(demanddraft)) > 10001);

	    }


}
