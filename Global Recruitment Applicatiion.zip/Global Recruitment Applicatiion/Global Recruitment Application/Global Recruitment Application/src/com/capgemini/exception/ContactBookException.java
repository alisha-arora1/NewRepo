package com.capgemini.exception;

public class ContactBookException extends Exception{

	public ContactBookException() {
		super();
		
	}

	
	public ContactBookException(String message, Throwable cause) {
		super(message, cause);
		
	}



}
