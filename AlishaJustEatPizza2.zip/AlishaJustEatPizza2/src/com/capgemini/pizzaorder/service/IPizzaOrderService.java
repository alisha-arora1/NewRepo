package com.capgemini.pizzaorder.service;

import java.util.Map;

import com.capgemini.pizzaorder.bean.Customer;
import com.capgemini.pizzaorder.bean.Pizza;
import com.capgemini.pizzaorder.exception.PizzaException;

public interface IPizzaOrderService 
{
	public int placeOrder(Customer customer,Pizza pizza) throws PizzaException;
	public Pizza displayOrder(int orderid) throws PizzaException;
	public double Calculateprice(Pizza pizza);

}
