package com.capgemini.pizzaorder.service;

import java.util.Map;
import java.util.regex.Pattern;

import com.capgemini.pizzaorder.bean.Customer;
import com.capgemini.pizzaorder.bean.Pizza;
import com.capgemini.pizzaorder.dao.IPizzaOrderDAO;
import com.capgemini.pizzaorder.dao.PizzaOrderDAO;
import com.capgemini.pizzaorder.exception.PizzaException;
import com.capgemini.pizzaorder.service.IPizzaOrderService;

public class PizzaOrderService implements IPizzaOrderService
{
	static IPizzaOrderDAO ipd= new PizzaOrderDAO(); ;
	//The method to add the details in the map
	@Override
	public int placeOrder(Customer customer, Pizza pizza)
			throws PizzaException 
	{
		
		return ipd.placeOrder(customer,pizza);
		
		
	}
	@Override
	public Pizza displayOrder(int orderid) throws PizzaException {
		// TODO Auto-generated method stub
		return ipd.displayOrder(orderid);
	}
	@Override
	public double Calculateprice(Pizza pizza) {
		// TODO Auto-generated method stub
		return ipd.Calculateprice(pizza);
	}
}
	
	//The method to get all the details from the map
	