package com.capgemini.pizzaorder.bean;

public enum VegToppings{
  Capsicum,
  Mushroom,
 Jalapeno,
 Paneer;
}
