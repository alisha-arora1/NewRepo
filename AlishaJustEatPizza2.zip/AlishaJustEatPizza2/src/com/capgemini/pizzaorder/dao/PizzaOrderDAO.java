package com.capgemini.pizzaorder.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

import org.apache.log4j.Logger;

import com.capgemini.pizzaorder.bean.Customer;
import com.capgemini.pizzaorder.bean.Pizza;
import com.capgemini.pizzaorder.bean.VegToppings;
import com.capgemini.pizzaorder.exception.PizzaException;
import com.capgemini.pizzaorder.util.DBUtils;



public class PizzaOrderDAO implements IPizzaOrderDAO
{
	
	
	Logger logger=Logger.getRootLogger();

	private Connection dbConnection; // ???

	{
		try {
			dbConnection = DBUtils.getConnection();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
    
	private int generateorderid() throws SQLException{
		String query="select pizzaSeq.nextval from dual";
		PreparedStatement querys=dbConnection.prepareStatement(query);
		ResultSet result=querys.executeQuery();
		result.next();
		int id= result.getInt(1);
		return id;
		
	}

	private int generatecustomerid() throws SQLException{
		String query="select customerSeq.nextval from dual";
		PreparedStatement querys=dbConnection.prepareStatement(query);
		ResultSet result=querys.executeQuery();
		result.next();
		int id= result.getInt(1);
		return id;
		
	}
	@Override
	public int placeOrder(Customer customer, Pizza pizza) throws PizzaException {
		// TODO Auto-generated method stub
		String insertquery="insert into pizza_entry values( ?,?,?,?)";
		String insertquery1="insert into customer_details values(?,?,?,?)";
		try{
			PreparedStatement insertstatement= dbConnection.prepareStatement(insertquery);
			PreparedStatement insertstatement1= dbConnection.prepareStatement(insertquery1);

			int id= generateorderid();
			int cid=generatecustomerid();
			pizza.setOrderid(id);
			pizza.setCustomerId(cid);
			customer.setCustomerid(cid);
			insertstatement1.setInt(1, cid);
			insertstatement1.setString(2, customer.getCustName());
			insertstatement1.setString(3, customer.getAddress());
			insertstatement1.setString(4, customer.getPhone());

			insertstatement.setInt(1, id);
			insertstatement.setInt(2, cid);
			insertstatement.setDouble(3, pizza.getTotalPrice());
			Date date = new Date(pizza.getOrderdate().getTime());			
			insertstatement.setDate(4, date);
			insertstatement1.executeUpdate();
			insertstatement.executeUpdate();
			
			logger.info("\n Your Pizza Order is placed along with OrderID :"+id);
			return id;
		}catch(Exception e){
			e.printStackTrace();
			return 0;
		}
	
	}

	@Override
	public Pizza displayOrder(int orderid) throws PizzaException {
        String displayquery="select * from pizza_entry where orderid=?";
        try{
			PreparedStatement displaystatement= dbConnection.prepareStatement(displayquery);
			displaystatement.setInt(1, orderid);
            ResultSet result=displaystatement.executeQuery();
            while(result.next()){
            	Pizza pizza = new Pizza();
            	pizza.setOrderid(result.getInt(1));
            	pizza.setCustomerId(result.getInt(2));
            	pizza.setTotalPrice(result.getDouble(3));
            	pizza.setOrderdate(result.getDate(4));
            	return pizza;
            	
            }
        }catch(Exception e){
			e.printStackTrace();
			return null;
		}
        
		return null;
	}

	@Override
	public double Calculateprice(Pizza pizza) {
		// TODO Auto-generated method stub
		double fixamount=350;
		double price=0;
		//double tax= 0.04;
		
		VegToppings v= pizza.getToppings();
		if(v.equals(v.Capsicum)){
			
			double vat= (fixamount+30)*0.04;
			price= (fixamount+30)+ vat;
			
		}
		else if(v.equals(v.Mushroom)){
			
			double vat= (fixamount+50)*(0.04);
			price= (fixamount+50)+ vat;
			
		}
	else if(v.equals(v.Jalapeno)){
		
		double vat= (fixamount+70)*(0.04);
		price= (fixamount+70)+ vat;
		
	}	
	else if(v.equals(v.Paneer)){
		
		double vat= (fixamount+85)*(0.04);
		price= (fixamount+85)+ vat;
		
	}
		return price;
}
	

	//The method to add the details in the map
} 

