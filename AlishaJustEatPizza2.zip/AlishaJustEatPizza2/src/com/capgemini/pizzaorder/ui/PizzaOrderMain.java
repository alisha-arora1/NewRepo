package com.capgemini.pizzaorder.ui;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

import com.capgemini.pizzaorder.bean.Customer;
import com.capgemini.pizzaorder.bean.Pizza;
import com.capgemini.pizzaorder.bean.VegToppings;
import com.capgemini.pizzaorder.exception.PizzaException;
import com.capgemini.pizzaorder.service.IPizzaOrderService;
import com.capgemini.pizzaorder.service.PizzaOrderService;

public class PizzaOrderMain 
{
	static Scanner sc=null;
	static Random rand=null;
	static Customer customer =null;
	static Pizza pizzaorder=null;
	static double totalPrize;
	static IPizzaOrderService ips= new PizzaOrderService(); 
	public static void main(String[] args) throws PizzaException
	{
		sc=new Scanner(System.in);
		int option;
		while(true)
		{
		System.out.println("-----------------------------------------");
		System.out.println("Menu:");
		System.out.println("1)Place Order");
		System.out.println("2)Display Order");
		System.out.println("3)Exit");
		System.out.print("Enter your Choice: ");
		option=sc.nextInt();
		switch(option){
		case 1:System.out.println("PIZZA TOPPINGS              PRICE(in Rs)");
		       System.out.println("Capsicum                    30");
	           System.out.println("Mushroom                    50");
		       System.out.println("Jalapeno                    70");
		       System.out.println("Paneer                      85");
		       System.out.println("Customer Details:"); 
			    System.out.print("\nEnter the name of the customer: ");
		        String name=sc.next();
		        System.out.print("Enter customer address: ");
		        String address= sc.next();
		        System.out.print("Enter customer phone number: ");
		        String number=sc.next();
		        Customer customer= new Customer();
		        customer.setAddress(address);
		        customer.setCustName(name);
		        customer.setPhone(number);
		        System.out.print("Type of pizza topping preferred:");
		        String topping=sc.next();
		        VegToppings vt=VegToppings.valueOf(topping);
		        Pizza pizza = new Pizza();
		        pizza.setToppings(vt);
		        double price = ips.Calculateprice(pizza);
		        pizza.setTotalPrice(price);
		        System.out.println("Price: "+ price);
		        
		        pizza.setOrderdate(new Date());
		        
		        
		        
		        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		    	Date date = new Date();
		    	System.out.println("Order Date:"+dateFormat.format(date)); //2016/11/16 12:08:43
		        
		        
		        
		        int id= ips.placeOrder(customer, pizza);
		        System.out.println("\nPizza Order successfully placed with Order Id :"+id);
		        break;
		case 2: System.out.print("\n Enter OrerId: ");
		        int oid= sc.nextInt();
		        Pizza pizza1= ips.displayOrder(oid);
		        System.out.println("\n Order ID: "+ pizza1.getOrderid());
		        System.out.println("\n Total Price: "+ pizza1.getTotalPrice());
		        System.out.println("\n Order Date: "+ pizza1.getOrderdate());
		        break;
		case 3: System.out.println("\n Exit");
		        System.exit(0);
		        break;
		        
		        
		        
		}
		}
	}
}
	